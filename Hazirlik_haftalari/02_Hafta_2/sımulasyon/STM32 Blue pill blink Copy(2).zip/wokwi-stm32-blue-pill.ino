#define BUTON_PIN PA4
#define LED_PIN PA5

void setup() { //setup yapılıyor
  pinMode(LED_PIN, OUTPUT); //kartın üzerindeki dahili ledin bağlı olduğu pini çıkış olarak ayarla
  pinMode(BUTON_PIN, INPUT_PULLDOWN);
}

void loop() { //sonsuz döngü başlatılıyor
  if(digitalRead(BUTON_PIN)==HIGH){
    digitalWrite(LED_PIN,HIGH); 
  }
  else{
    digitalWrite(LED_PIN, LOW);
  }
}
