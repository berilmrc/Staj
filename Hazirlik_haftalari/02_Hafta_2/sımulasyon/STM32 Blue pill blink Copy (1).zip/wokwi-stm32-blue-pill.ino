void setup() { //setup yapılıyor
  pinMode(LED_BUILTIN, OUTPUT); //kartın üzerindeki dahili ledin bağlı olduğu pini çıkış olarak ayarla
  }

void loop() { //sonsuz döngü başlatılıyor
  digitalWrite(LED_BUILTIN,HIGH); //led yanar
  delay(500); //bekleme
  digitalWrite(LED_BUILTIN, LOW);  //led söner
  delay(500);  //bekleme
}
