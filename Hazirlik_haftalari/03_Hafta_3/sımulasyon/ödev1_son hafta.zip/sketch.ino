#include "stm32c0xx_hal.h"
#include <string.h>
#include <stdio.h> // printf fonksiyonu için standart G/Ç kütüphanesini ekliyoruz

UART_HandleTypeDef huart2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);

// SysTick Kesmesi (HAL_Delay ve HAL_GetTick için saat atımını sağlar)
void SysTick_Handler(void)
{
  HAL_IncTick();
}

// Donanımsal UART Pin Ayarları (MSP)
void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(huart->Instance == USART2)
  {
    __HAL_RCC_USART2_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    
    GPIO_InitStruct.Pin = GPIO_PIN_2 | GPIO_PIN_3;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF1_USART2;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  }
}

// =========================================================
// PRINTF YÖNLENDİRMESİ (RETARGETING)
// printf() çağrıldığında veriler otomatik olarak bu fonksiyona gelir.
// Biz de bu verileri alıp huart2 (USART2) üzerinden gönderiyoruz.
// =========================================================
int _write(int file, char *ptr, int len) 
{
  HAL_UART_Transmit(&huart2, (uint8_t*)ptr, len, HAL_MAX_DELAY);
  return len;
}

int main(void)
{
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART2_UART_Init();

  uint8_t onceki_durum = GPIO_PIN_RESET; 
  uint8_t mevcut_durum = GPIO_PIN_RESET;

  // Sayaç ve zaman takibi için değişkenler
  uint32_t sayac = 0;
  uint32_t son_yazdirma_zamani = 0;

  // printf yönlendirmesini test ediyoruz
  printf("\r\n--- Sistem Basladi! ---\r\n");

  while (1)
  {
    /* ---------------------------------------------------
       GÖREV 1: DÜZENLİ SAYAÇ YAZDIRMA (Non-Blocking)
       --------------------------------------------------- */
    // Eğer son yazdırmanın üzerinden 1000 milisaniye (1 saniye) geçmişse
    /*if (HAL_GetTick() - son_yazdirma_zamani >= 1000) 
    {
      // Sayaç değerini formatlayarak gönder
      printf("Sayac Degeri: %lu\r\n", sayac);
      
      sayac++; // Sayacı artır
      son_yazdirma_zamani = HAL_GetTick(); // Zamanı sıfırla/kaydet
    }
*/
    /* ---------------------------------------------------
       GÖREV 2: BUTON OKUMA VE LED KONTROLÜ
       --------------------------------------------------- */
    mevcut_durum = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0);

    if (mevcut_durum != onceki_durum)
    {
      HAL_Delay(20); 
      mevcut_durum = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0); 

      if (mevcut_durum != onceki_durum) 
      {
        onceki_durum = mevcut_durum; 

        if (mevcut_durum == GPIO_PIN_SET)
        {
          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET); 
          sayac++;
          printf("Sayac Degeri: %lu\r\n", sayac);
          // Artık HAL_UART_Transmit yerine doğrudan printf kullanabiliriz!
          printf("-> Butona Basildi - LED Yandi!\r\n");
        }
        else
        {
          HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
          printf("-> Buton Birakildi - LED Sondu!\r\n");
        }
      }
    }
  }
}

// --- UART ve GPIO Ayarları ---
static void MX_USART2_UART_Init(void)
{
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  HAL_UART_Init(&huart2);
}

static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOA_CLK_ENABLE();

  GPIO_InitStruct.Pin = GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN; 
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}

void SystemClock_Config(void) {}